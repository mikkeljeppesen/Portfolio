var main = function() {

	var paused = false

	$('.arrowR').click(function() {
		paused = true;
		let currentImg = 
			$('#slideshow > img:first')
			.fadeOut(0.02)
			.next()
			console.log(currentImg)
			
			currentImg.fadeIn()
			.end()
			.appendTo('#slideshow');

			console.log(currentImg[0].dataset.id)

			fetch("https://swapi.co/api/people/"+ (currentImg[0].dataset.id) +"/" )
			.then(function (response) {
				return response.json();
			})
			.then(function (data) {
				console.log(data.name);

				let indholdElement = document.querySelector(".indhold");
				let pNameElement = document.querySelector("p.navn")
				let pAgeElement = document.querySelector("p.alder")
				let pMassElement = document.querySelector("p.vægt")

				pNameElement.innerHTML = data.name;
				pAgeElement.innerHTML = data.birth_year;
				pMassElement.innerHTML = data.mass + "kg";
			}); 
	});
		
	$('.arrowL').click(function() {

		paused = true;
        let currentImg = 
            $('#slideshow > img:last')
		    .fadeIn()
		    .prependTo('#slideshow')  
            .next()
            .fadeOut(0.02)
            .end();
            
			fetch("https://swapi.co/api/people/"+ (currentImg[0].dataset.id) +"/" )
			.then(function (response) {
				return response.json();
			})
            .then(function(data){
                console.log(data.name);   
    
				let indholdElement = document.querySelector(".indhold");
				let pNameElement = document.querySelector("p.navn")
				let pAgeElement = document.querySelector("p.alder")
				let pMassElement = document.querySelector("p.vægt")
                        
				pNameElement.innerHTML = data.name;
				pAgeElement.innerHTML = data.birth_year;
				pMassElement.innerHTML = data.mass + "kg";
            });
        
	});
	
};

$(document).ready(main);