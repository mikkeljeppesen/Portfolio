// play button function start //
    let lamaElement = document.querySelector(".lama");
    lamaElement.src = ("assets/lama.png");
    let gevinstElement = document.querySelector(".gevinst");
    let addVbucks = document.querySelector(".money");
    let audioBuzzer = new Audio("assets/buzzer.mp3");
    let audioClick = new Audio("sound/click.mp3");
    let audioOpening = new Audio("sound/opening.mp3");
    let audioSwoosh = new Audio("sound/swoosh.mp3");
    let audioMoney = new Audio ("sound/money.mp3");
    let audioWin = new Audio ("sound/win.mp3");
    let audioLoose = new Audio ("sound/loose.mp3");
    let audioStart = new Audio ("sound/start.mp3");
    let playButtonElement = document.querySelector(".play_button");
    let addButtonElement = document.querySelector(".add_button");

    
   async function start() {
        await sleep(500);
        audioStart.play();
        await sleep(4500);
        playButtonElement.classList.remove("noclick");
        addButtonElement.classList.remove("noclick");


    }

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    
    async function finish_game(){
        await sleep(8000);
        //gevinstElement.classList.add("hidegevinst");
        card01.classList.add("animationout");
        card02.classList.add("animationout");
        card03.classList.add("animationout");
        await sleep (800);
        card01.classList.remove("animationout");
        card02.classList.remove("animationout");
        card03.classList.remove("animationout");

        card01.classList.remove("animationin");
        card02.classList.remove("animationin");
        card03.classList.remove("animationin");
        
        lamaElement.src = ("assets/lama.png");
        
        card01.src = "";
        card02.src = "";
        card03.src = "";
    }
    async function demo() {
        audioBuzzer.play();
        await sleep(900);
        
        addVbucks.classList.remove("no_v-bucks");
        addVbucks.classList.add("v-bucks");
    }






    playButtonElement.classList.add("animationbtn");


    playButtonElement.addEventListener("click", function(){
       
        if (newValueElement > 9) {
            lamaElement.src = ("assets/lama.gif");
            audioOpening.play();
            playButtonElement.disabled = true;
            setTimeout(function() {
                playButtonElement.disabled = false;
            }, 8000);
            newValueElement = newValueElement - 10;
            h3Element.innerHTML = "V-BUCKS: " + newValueElement;

            

            setTimeout(function() {
                lamaElement.src = ("assets/platform.png");
            }, 3000);

            randomcard();

                gevinstElement.classList.remove("hidegevinst");
                gevinstElement.classList.add("showgevinst");
                finish_game();

            console.log("play button trykket");
        }

        else {
            //alert ("You need some V-BUCKS"); 
            addVbucks.classList.remove("v-bucks");
            addVbucks.classList.add("no_v-bucks");
              
            demo();
  
        } 
    });

// play button function slut //


// add coins button function start //

let h3Element = document.querySelector(".money");
let newValueElement = 20;
let addValueElement = 20;



    h3Element.innerHTML = "V-BUCKS: " + newValueElement;

    addButtonElement.addEventListener("click", function(){       
        audioMoney.currentTime = 0;
        audioMoney.play();
        newValueElement = newValueElement + addValueElement;
        h3Element.innerHTML =  "V-BUCKS: " + newValueElement;
    });

// add coins button function slut //


