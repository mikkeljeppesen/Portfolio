var wheel1 = [
    "assets/loveranger_card.png",

    "assets/paperparasol_card.png",

    "assets/partanimal_card.png",

    "assets/bluestreak_card.png",

    "assets/burnout_card.png",

    "assets/codenameE.L.F_card.png",

    "assets/rex_card.png",
    
    "assets/thereapor_card.png",

    "assets/triceraops_card.png",

    "assets/rustlord_card.png",

    "assets/stagedive_card.png",

    "assets/spaceglider_card.png",

    "assets/anarchyaxe_card.png",

    "assets/dragonaxe_card.png",

    "assets/merrymarauder_card.png",
    
    "assets/missionspecialist_card.png",

    "assets/tataxe_card.png",

    "assets/eva_card.png",

    "assets/googly_card.png",

    "assets/raven_card.png",

    "assets/crackshot_card.png",

    "assets/cuddleteamleader_card.png",
    
    "assets/rainbowsmash_card.png",

    "assets/wukong_card.png"
];


var wheel2 = [
    

    "assets/wukong_card.png"
    
];

var card01 = "";
var card02 = "";
var card03 = "";
 
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function randomcard(){

    var left = wheel1[Math.floor(Math.random() * wheel1.length)]; 

    var mid = wheel2[Math.floor(Math.random() * wheel2.length)]; 

    var right = wheel2[Math.floor(Math.random() * wheel2.length)]; 

    console.log(left, mid, right);

    // -----------------------------------------------------//

    var gevinstElement = document.querySelector(".gevinst");
    var inventoryWinElement = document.querySelector("#cards_win");
    console.log("Cards win: " + inventoryWinElement);

    await sleep(3000);
    card01 = document.querySelector(".card01");
    card01.classList.add("animationin");
    audioSwoosh.play();
    console.log (card01);
    card01.src = left;
    await sleep(1000);
    card02 = document.querySelector(".card02");
    card02.classList.add("animationin");
    audioSwoosh.currentTime = 0;
    audioSwoosh.play();
    card02.src = mid;
    await sleep(1000);
    card03 = document.querySelector(".card03");
    card03.classList.add("animationin");
    audioSwoosh.currentTime = 0;
    audioSwoosh.play();
    card03.src = right;


    console.log(card01);


    if (left == mid && mid == right) {
        console.log("DE er ens");
        
        var DOM_img = document.createElement("img");
        DOM_img.src = mid;
        

        DOM_img.classList.add("animated");
        DOM_img.classList.add("slideInRight");

        setTimeout(function() {
        inventoryWinElement.prepend(DOM_img);
        audioWin.play();
        }, 3000);   
    }  

    else {
        console.log("DE er ikke ens");
        await sleep(1200);
        audioLoose.play();
    }
}






